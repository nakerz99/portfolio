# Resume Download Instructions

If you're viewing this resume in the browser, you can save it as a PDF by:

1. Using your browser's print function (Ctrl+P or Cmd+P)
2. Select "Save as PDF" as the destination
3. Click "Save" or "Print"

This will create a professionally formatted PDF version of the resume.
